ArchSmarter Toolbox v1.15

To run the macros, first load the RVT file.
Next, make active the Revit file you want to run the macro on.
Go to Manage > Macro Manager.
In the Macro Manager dialog, select the macro you want to run then click the "Run" button. 

To see a video demonstration of the process, go to: https://archsmarter.com/go/run-revit-macro/

Please email me with any questions or issues (michael@archsmarter.com)

Enjoy!
Michael
